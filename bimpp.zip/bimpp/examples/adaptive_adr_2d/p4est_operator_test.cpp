#include <cassert>
#include <vector>

#include <bim_sparse.h>
#include <mumps_class.h>
#include <octave_file_io.h>
#include <quad_operators.h>
#include <tmesh.h>


int
write_example_connectivity (const char* filename)
{
  std::vector<double> p =
    {0.00000, 0.00000, 0.00000, 0.00000,
     0.25000, 0.25000, 0.25000, 0.25000,
     0.75000, 0.75000, 0.75000, 0.75000,
     1.00000, 1.00000, 1.00000, 1.00000,
     //
     0.00000, 0.25000, 0.75000, 1.00000,
     0.00000, 0.25000, 0.75000, 1.00000,
     0.00000, 0.25000, 0.75000, 1.00000,
     0.00000, 0.25000, 0.75000, 1.00000};
  
  std::vector<octave_idx_type> t =
    { 1,  5,  6,  2, 1,
      2,  6,  7,  3, 1,
      3,  7,  8,  4, 1,
      5,  9, 10,  6, 1,
      6, 10, 11,  7, 1,
      7, 11, 12,  8, 1,
      9, 13, 14, 10, 1,
      10, 14, 15, 11, 1,
      11, 15, 16, 12, 1};
  
  // save data to file
  Matrix oct_p (p.size() / 2, 2, 0.0);
  Array<octave_idx_type> oct_t (dim_vector (5, t.size () / 5), 0);
  
  std::copy_n (p.begin (), p.size (), oct_p.fortran_vec ());
  oct_p = oct_p.transpose ();
  std::copy_n (t.begin (), t.size (), oct_t.fortran_vec ());
  
  octave_scalar_map the_map;
  the_map.assign ("p", oct_p);
  the_map.assign ("t", oct_t);
  
  octave_io_mode m = gz_write_mode;
  int CHK;
  CHK = octave_io_open (filename, m, &m); assert (CHK == 0);
  CHK = octave_save ("msh", octave_value (the_map)); assert (CHK == 0);
  CHK = octave_io_close (); assert (CHK == 0);
  
  return 0;
}

static int
uniform_refinement (tmesh::quadrant_iterator quadrant)
{ return 1; }

int
main (int argc, char **argv)
{
  MPI_Init (&argc, &argv);
  
  int                   recursive, partforcoarsen, balance;
  MPI_Comm              mpicomm = MPI_COMM_WORLD;  
  int                   rank, size;
  tmesh                 tmsh;
  
  mpicomm = MPI_COMM_WORLD;
  MPI_Comm_rank (mpicomm, &rank);
  MPI_Comm_size (mpicomm, &size);

  if (rank == 0)
    write_example_connectivity ("p4est_operator_test.octbin");

  tmsh.read_connectivity ("p4est_operator_test.octbin.gz");
  
  // Uniform refinement.
  recursive = 0; partforcoarsen = 1;
  for (int cycle = 0; cycle < 4; ++cycle)
    {
      tmsh.set_refine_marker (uniform_refinement);
      tmsh.refine (recursive, partforcoarsen);
    }
  
  tmsh.vtk_export ("p4est_operator_test");
  
  // Assemble advection-diffusion matrix.
  sparse_matrix A;
  A.resize(tmsh.num_global_nodes());
  
  std::vector<double> alpha(tmsh.num_local_quadrants (), 1);
  std::vector<double> psi(tmsh.num_global_nodes (), 0);
  
  double x = 0, y = 0, rho = 0;
  
  for (auto quadrant = tmsh.begin_quadrant_sweep ();
       quadrant != tmsh.end_quadrant_sweep ();
       ++quadrant)
    {
      for (int ii = 0; ii < 4; ++ii)
        {
          if (! quadrant->is_hanging (ii))
            {
              x = quadrant->p(0, ii);
              y = quadrant->p(1, ii);
              
              rho = std::sqrt(x * x + y * y);
              
              if (rho >= 0.8 && rho <= 0.9)
                psi[quadrant->gt(ii)] = -(2 * rho - 0.8) / 1e-2;
              else if (rho >= 0.9)
                psi[quadrant->gt(ii)] = -0.2 / 1e-2;
            }
        }
    }
  
  // Reduce coefficients.
  std::vector<double> global_psi(tmsh.num_global_nodes(), 0);
  MPI_Allreduce(psi.data(), global_psi.data(), psi.size(),
                MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
  
  bim2a_advection_diffusion (tmsh, alpha, global_psi, A);
  
  // Assemble right-hand side.
  std::vector<double> rhs(tmsh.num_global_nodes (), 0);
  
  std::vector<double> f(tmsh.num_local_quadrants (), 0);
  std::vector<double> g(tmsh.num_global_nodes (), 0);
  
  bim2a_rhs (tmsh, f, g, rhs);
  
  // Set boundary conditions.
  dirichlet_bcs bcs;
  bcs.push_back (std::make_tuple(0, 0, [] (double x, double y) { return 0.3; }));
  bcs.push_back (std::make_tuple(0, 2, [] (double x, double y) { return 0.3; }));
  bcs.push_back (std::make_tuple(8, 1, [] (double x, double y) { return 0; }));
  bcs.push_back (std::make_tuple(8, 3, [] (double x, double y) { return 0; }));
  
  bim2a_dirichlet_bc (tmsh, bcs, A, rhs);
  
  // Solve problem.
  std::cout << "Solving linear system." << std::endl;
  
  mumps mumps_solver;
  
  std::vector<double> vals;
  std::vector<int> irow, jcol;
  
  A.aij(vals, irow, jcol, mumps_solver.get_index_base ());
  
  mumps_solver.set_lhs_distributed ();
  mumps_solver.set_distributed_lhs_structure (A.rows (), irow, jcol);
  mumps_solver.set_distributed_lhs_data (vals);
  
  // Reduce rhs (so that rank 0 has the actual rhs).
  std::vector<double> global_rhs(tmsh.num_global_nodes(), 0);
  MPI_Allreduce(rhs.data(), global_rhs.data(), rhs.size(), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
  
  if (rank == 0)
    mumps_solver.set_rhs (global_rhs);
  
  // Solve.
  mumps_solver.analyze ();
  mumps_solver.factorize ();
  mumps_solver.solve ();
  mumps_solver.cleanup ();
  
  // Export solution.
  MPI_Bcast(global_rhs.data(), global_rhs.size(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
  tmsh.octbin_export ("p4est_operator_test_output", global_rhs);
  
  MPI_Finalize ();
  
  return 0;
}
