#include <bim_sparse.h>
#include <mumps_class.h>
#include <quad_operators.h>
#include <tmesh.h>

#include <vector>
#include <limits>

// Define mesh.
constexpr p4est_topidx_t simple_conn_num_vertices = 6;
constexpr p4est_topidx_t simple_conn_num_trees = 2;
const double simple_conn_p[simple_conn_num_vertices*2] = {0, 0, 1, 0, 1, 0.5, 0, 0.5, 1, 1, 0, 1};
const p4est_topidx_t simple_conn_t[simple_conn_num_trees*5] = {1, 2, 3, 4, 1, 4, 3, 5, 6, 1};

static int
uniform_refinement (tmesh::quadrant_iterator q)
{ return 1; }

static constexpr unsigned refine_steps = 10;

int
main (int argc, char **argv)
{
  MPI_Init (&argc, &argv);
  
  int                   recursive, partforcoarsen, balance;
  MPI_Comm              mpicomm = MPI_COMM_WORLD;  
  int                   rank, size;
  tmesh                 tmsh;
  
  mpicomm = MPI_COMM_WORLD;
  MPI_Comm_rank (mpicomm, &rank);
  MPI_Comm_size (mpicomm, &size);

  tmsh.read_connectivity (simple_conn_p, simple_conn_num_vertices,
                          simple_conn_t, simple_conn_num_trees);
  
  recursive = 0; partforcoarsen = 1;
  for (int cycle = 0; cycle < 2; ++cycle)
    {
      tmsh.set_refine_marker (uniform_refinement);
      tmsh.refine (recursive, partforcoarsen);
    }
  
  tmsh.vtk_export ("p4est_dr_test_3_uniform");
  
  std::vector<tmesh::idx_t> nnodes;
  std::vector<double> h_step;
  std::vector<double> error, error_du;
  std::vector<double> error_star, error_star_du;
  
  for (int adapt = 0; adapt < refine_steps; ++adapt)
    {
      std::cout << "*** Step " << adapt << " ***" << std::endl;
      
      // Compute coefficients.
      double eps1 = 5e-5;
      double eps2 = 1e-1;
      
      double c = -0.4375 * eps2 /
        (0.5 * std::sqrt(eps1) * std::cosh(0.5 / std::sqrt(eps1)) +
         eps2 * std::sinh(0.5 / std::sqrt(eps1)));
      
      double d = 1.75 * std::sqrt(eps1) * std::cosh(0.5 / std::sqrt(eps1)) /
        (std::sqrt(eps1) * std::cosh(0.5 / std::sqrt(eps1)) +
         2 * eps2 * std::sinh(0.5 / std::sqrt(eps1)));
      
      std::vector<double> alpha(tmsh.num_local_quadrants (), eps1);
      std::vector<double> psi(tmsh.num_global_nodes (), 0);
      
      std::vector<double> delta(tmsh.num_local_quadrants (), 1);
      std::vector<double> zeta(tmsh.num_global_nodes (), 1);
      
      std::vector<double> f(tmsh.num_local_quadrants (), 1);
      std::vector<double> g(tmsh.num_global_nodes (), 1);
      
      for (auto quadrant = tmsh.begin_quadrant_sweep ();
           quadrant != tmsh.end_quadrant_sweep ();
           ++quadrant)
        {
          if (quadrant->p(1, 0) >= 0.5)
            {
              alpha[quadrant->get_forest_quad_idx()] = eps2;
              delta[quadrant->get_forest_quad_idx()] = 0;
              f[quadrant->get_forest_quad_idx()] = eps2;
            }
        }
      
      // Assemble system matrix and right-hand side.
      sparse_matrix A, M;
      A.resize(tmsh.num_global_nodes());
      M.resize(tmsh.num_global_nodes());
      bim2a_advection_diffusion (tmsh, alpha, psi, A);
      bim2a_reaction (tmsh, delta, zeta, M);
      A += M;
      
      std::vector<double> rhs(tmsh.num_global_nodes (), 0);
      bim2a_rhs (tmsh, f, g, rhs);
      
      // Set boundary conditions.
      func u_ex =
        [eps1, eps2, c, d] (double x, double y)
        {
          if (y <= 0.5)
            return (1 + 2 * c * std::sinh(y / std::sqrt(eps1)));
          else
            return (-0.5 * (y - 1) * (y + 2 * d));
        };
      
      dirichlet_bcs bcs;
      bcs.push_back (std::make_tuple(0, 2, u_ex));
      bcs.push_back (std::make_tuple(1, 3, u_ex));
      
      bim2a_dirichlet_bc (tmsh, bcs, A, rhs);
      
      // Solve problem.
      std::cout << "Solving linear system.";
      
      mumps mumps_solver;
      
      std::vector<double> vals;
      std::vector<int> irow, jcol;
      
      A.aij(vals, irow, jcol, mumps_solver.get_index_base ());
      
      mumps_solver.set_lhs_distributed ();
      mumps_solver.set_distributed_lhs_structure (A.rows (), irow, jcol);
      mumps_solver.set_distributed_lhs_data (vals);
      
      // Reduce rhs (so that rank 0 has the actual rhs).
      std::vector<double> global_rhs(tmsh.num_global_nodes(), 0);
      MPI_Reduce(rhs.data(), global_rhs.data(), rhs.size(),
                 MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
      
      if (rank == 0)
        mumps_solver.set_rhs (global_rhs);
      
      // Solve.
      mumps_solver.analyze ();
      mumps_solver.factorize ();
      mumps_solver.solve ();
      mumps_solver.cleanup ();
      
      // Export solution.
      MPI_Bcast(global_rhs.data(), global_rhs.size(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
      tmsh.octbin_export ((std::string("p4est_dr_test_3_uniform_u_")
                           + std::to_string(adapt)).c_str(), global_rhs);
      
      std::vector<double> uex(tmsh.num_global_nodes(), 0);
      
      for (auto quadrant = tmsh.begin_quadrant_sweep ();
           quadrant != tmsh.end_quadrant_sweep ();
           ++quadrant)
        for (int i = 0; i < 4; ++i)
          uex[quadrant->gt(i)] = u_ex(quadrant->p(0, i), quadrant->p(1, i));
      
      tmsh.octbin_export ((std::string("p4est_dr_test_3_uniform_uex_")
                           + std::to_string(adapt)).c_str(), uex);
      
      std::cout << " Done." << std::endl;
      
      // Compute reconstructed gradient.
      std::cout << "Computing reconstructed gradient and solution.";
      
      active_fun tree0 = [] (tmesh::quadrant_iterator q)
        { return (q->get_tree_idx () == 0); };
      
      active_fun tree1 = [] (tmesh::quadrant_iterator q)
        { return (q->get_tree_idx () == 1); };
      
      gradient<std::vector<double>> du0 = bim2c_quadtree_pde_recovered_gradient(tmsh, global_rhs, tree0);
      gradient<std::vector<double>> du1 = bim2c_quadtree_pde_recovered_gradient(tmsh, global_rhs, tree1);
      
      q2_vec u_star0 = bim2c_quadtree_pde_recovered_solution(tmsh, global_rhs, du0);
      q2_vec u_star1 = bim2c_quadtree_pde_recovered_solution(tmsh, global_rhs, du1);
      
      tmsh.octbin_export ((std::string("p4est_dr_test_3_uniform_du0_x_")
                           + std::to_string(adapt)).c_str(), du0.first);
      tmsh.octbin_export ((std::string("p4est_dr_test_3_uniform_du0_y_")
                           + std::to_string(adapt)).c_str(), du0.second);
      
      tmsh.octbin_export ((std::string("p4est_dr_test_3_uniform_du1_x_")
                           + std::to_string(adapt)).c_str(), du1.first);
      tmsh.octbin_export ((std::string("p4est_dr_test_3_uniform_du1_y_")
                           + std::to_string(adapt)).c_str(), du1.second);
      
      std::cout << " Done." << std::endl;
      
      // Compute h and error.
      double hx = 0, hy = 0,
        h = std::numeric_limits<double>::max (),
        global_h = 0;
      
      func du_x_ex =
        [] (double x, double y)
        { return 0; };
      
      func du_y_ex =
        [eps1, eps2, c, d] (double x, double y)
        {
          if (y <= 0.5)
            return (2 * c * std::cosh(y / std::sqrt(eps1)) / std::sqrt(eps1));
          else
            return (-y - d + 0.5);
        };
      
      double err    = 0, global_err    = 0;
      double err_du = 0, global_err_du = 0;
      double err_star    = 0, global_err_star    = 0;
      double err_star_du = 0, global_err_star_du = 0;
      
      for (auto quadrant = tmsh.begin_quadrant_sweep ();
           quadrant != tmsh.end_quadrant_sweep ();
           ++quadrant)
        {
          hx = quadrant->p(0, 1) - quadrant->p(0, 0);
          hy = quadrant->p(1, 2) - quadrant->p(1, 0);
          
          h = std::min(h, std::sqrt(hx*hx + hy*hy));
          
          err += std::pow(l2_error(quadrant, u_ex, global_rhs), 2);
          err_du += std::pow(semih1_error(quadrant, du_x_ex, du_y_ex, global_rhs), 2);
          
          if (tree0(quadrant))
            {
              err_star += std::pow(l2_star_error(quadrant, u_ex, u_star0), 2);
              err_star_du += std::pow(semih1_star_error(quadrant, du_x_ex, du_y_ex, du0), 2);
            }
          else
            {
              err_star += std::pow(l2_star_error(quadrant, u_ex, u_star1), 2);
              err_star_du += std::pow(semih1_star_error(quadrant, du_x_ex, du_y_ex, du1), 2);
            }
        }
      
      MPI_Reduce(&h, &global_h, 1, MPI_DOUBLE, MPI_MIN, 0, mpicomm);
      
      MPI_Reduce(&err,    &global_err,    1, MPI_DOUBLE, MPI_SUM, 0, mpicomm);
      MPI_Reduce(&err_du, &global_err_du, 1, MPI_DOUBLE, MPI_SUM, 0, mpicomm);
      MPI_Reduce(&err_star,    &global_err_star,    1, MPI_DOUBLE, MPI_SUM, 0, mpicomm);
      MPI_Reduce(&err_star_du, &global_err_star_du, 1, MPI_DOUBLE, MPI_SUM, 0, mpicomm);
      
      global_err    = std::sqrt(global_err);
      global_err_du = std::sqrt(global_err_du);
      global_err_star    = std::sqrt(global_err_star);
      global_err_star_du = std::sqrt(global_err_star_du);
      
      nnodes.push_back (tmsh.num_global_nodes ());
      h_step.push_back (global_h);
      error.push_back (global_err);
      error_du.push_back (global_err_du);
      error_star.push_back (global_err_star);
      error_star_du.push_back (global_err_star_du);
      
      std::cout << " Done." << std::endl;
      
      if (tmsh.num_global_nodes () >= 1e6)
        break;
      
      // Refine.
      tmsh.set_refine_marker (uniform_refinement);
      tmsh.refine (recursive, partforcoarsen);
      
      tmsh.vtk_export ((std::string("p4est_dr_test_3_uniform_newmesh_")
                        + std::to_string(adapt)).c_str());
    }
  
  if (rank == 0)
    for (unsigned step = 0; step < nnodes.size(); ++step)
      std::cout << "Step " << step << ", #nodes: "
                << nnodes[step] << ", h: "
                << h_step[step] << ", error: "
                << error[step] << ", error_du: "
                << error_du[step] << ", error^*: "
                << error_star[step] << ", error_du^*: "
                << error_star_du[step] << std::endl;
  
  MPI_Finalize ();
  
  return 0;
}
