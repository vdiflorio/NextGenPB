clear all;
clc;

export_tmesh_data ('tumor_growth_u_', {'tumor_growth_u_'}, {'u'}, {}, {},
                   "out", 0:10, 2);
