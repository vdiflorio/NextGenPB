pkg load bim

m = bim3c_mesh_properties (msh3m_gmsh ("patata.geo", "clscale", ".1"));
