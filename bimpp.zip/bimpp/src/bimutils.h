#ifndef HAVE_BIMUTIL_H
#define HAVE_BIMUTIL_H 1

void
bimu_bernoulli (double x, double &bp, double &bn);

void
bimu_bernoulli_derivative (double x, double &bpp, double &bnp);

#endif
