#ifndef MOSFET_DOPING
#  define MOSFET_DOPING

#include <tmesh_3d.h>

double doping (double x, double y, double z,
               double L, double H, double W);
double signedlog (double x);

#endif
