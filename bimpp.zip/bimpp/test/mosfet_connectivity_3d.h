int
write_example_connectivity3 (const char* filename);
