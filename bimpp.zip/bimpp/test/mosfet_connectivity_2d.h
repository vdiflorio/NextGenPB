int
write_example_connectivity (const char* filename);
