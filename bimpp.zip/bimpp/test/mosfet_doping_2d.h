#ifndef MOSFET_DOPING
#  define MOSFET_DOPING

#include <tmesh.h>

double doping (double x, double y, double L, double H);
double signedlog (double x);

#endif
